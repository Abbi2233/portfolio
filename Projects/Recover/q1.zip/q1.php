<?php

$dateTime =  time();


date_default_timezone_set('Africa/Cairo');
ini_set('date.timezone', 'Africa/Cairo');
$date = new DateTime("@$dateTime");

echo "Date: " . $date->format("Y-m-d") . "<br> Time: " . $date->format("h:i:s A");                    

function volume_hemi_shpere($r ) {
    $v;
$v = 2/3 * 3.14 * pow(r, 3);
funtion
if(v <= 0){
    ehco v;
    echo "INvalid ";
}
 else{
    ehco v;
    echo "valid ";

 }
}

volume_hemi_shpere(2);
volume_hemi_shpere(-2);

?>